========================================
ESP32 Camera Project - README
========================================

Features:
- Capture Image: Take a high-resolution photo using the ESP32 camera.
- Live Streaming: Stream video directly to your web browser.
- Adjustable LED Flash: Enhance image quality in low-light conditions.
- Cross-Platform Accessibility: Access the camera using any web browser.

----------------------------------------
Setup Instructions:
----------------------------------------

1. Hardware Requirements:
   - ESP32 camera module (e.g., ESP32-CAM, AI Thinker, M5Stack, etc.).
   - MicroUSB cable for power and data transfer.
   - WiFi network.

2. Configuration Steps:
   - Step 1: Set Up the Code
     1. Open the project files in the Arduino IDE or your preferred environment.
     2. Locate the file for WiFi configuration (e.g., `ImgSynth.ino` or `app_httpd.cpp`).
     3. Update the following lines with your WiFi credentials:
        ```
        const char* ssid = "YOUR_SSID";
        const char* password = "YOUR_PASSWORD";
        ```

   - Step 2: Upload the Code
     1. Connect the ESP32 to your computer using a USB cable.
     2. Select the correct board and port in the Arduino IDE:
        - Board: Select your ESP32 model (e.g., ESP32 Wrover, AI Thinker).
        - Port: Choose the COM port assigned to your ESP32.
     3. Upload the code to the ESP32 module.

   - Step 3: Get the IP Address
     1. Open the Serial Monitor in the Arduino IDE.
     2. After connecting to WiFi, the ESP32 will display its assigned IP address (e.g., `192.168.1.100`).

   - Step 4: Access the Web Interface
     1. Open your browser and navigate to the IP address displayed in the Serial Monitor.
        Example: `http://192.168.1.100`
     2. Use the following options:
        - **Capture Image**: Click to take a photo.
        - **Live Stream**: Click to start live video streaming.

----------------------------------------
Troubleshooting:
----------------------------------------

- Cannot Connect to WiFi:
  - Verify that the SSID and password are correct.
  - Check if the ESP32 is within WiFi range.

- No Output in Serial Monitor:
  - Ensure the correct baud rate (e.g., 115200) is set in the Serial Monitor.
  - Verify that the ESP32 is properly powered.

- Live Stream Not Working:
  - Check browser compatibility with MJPEG streaming.
  - Ensure no firewalls or VPNs block local IP addresses.

----------------------------------------
Credits and License:
----------------------------------------

This project is licensed under the Apache License, Version 2.0.
For more details, see the LICENSE file in the repository.

Happy coding!
